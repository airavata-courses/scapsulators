package com.ads.project1.databaseconnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatabaseConnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
