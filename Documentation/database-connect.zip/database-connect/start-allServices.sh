docker images
docker-compose rm -svf
docker-compose up
